-- =============================================================================
--  HOTEL BOOKINGS ANALYSIS — COMPLETE MySQL PROJECT
--  Dataset   : hotel_bookings.csv  (119,390 rows | 32 columns | 2015-2017)
--  Author    : Data Analyst
--  Purpose   : Exploratory Data Analysis + Business Insight Queries
--  Sections  : 0 Setup · 1 Cleaning · 2 Demand · 3 Seasonality
--              4 Geography · 5 Segmentation · 6 Revenue · 7 Cancellations
--              8 Rooms · 9 Operations · 10 Advanced · 11 Key Insights
-- =============================================================================

-- =============================================================================
-- SECTION 0 : DATABASE & TABLE SETUP
-- =============================================================================

CREATE DATABASE IF NOT EXISTS hotel_analysis;
USE hotel_analysis;

DROP TABLE IF EXISTS hotel_bookings;

CREATE TABLE hotel_bookings (
    id                              INT AUTO_INCREMENT PRIMARY KEY,
    hotel                           VARCHAR(50),
    is_canceled                     TINYINT,
    lead_time                       INT,
    arrival_date_year               YEAR,
    arrival_date_month              VARCHAR(15),
    arrival_date_week_number        INT,
    arrival_date_day_of_month       INT,
    stays_in_weekend_nights         INT,
    stays_in_week_nights            INT,
    adults                          INT,
    children                        INT,
    babies                          INT,
    meal                            VARCHAR(20),
    country                         CHAR(7),
    market_segment                  VARCHAR(30),
    distribution_channel            VARCHAR(30),
    is_repeated_guest               TINYINT,
    previous_cancellations          INT,
    previous_bookings_not_canceled  INT,
    reserved_room_type              CHAR(1),
    assigned_room_type              CHAR(1),
    booking_changes                 INT,
    deposit_type                    VARCHAR(20),
    agent                           VARCHAR(10),
    company                         VARCHAR(10),
    days_in_waiting_list            INT,
    customer_type                   VARCHAR(20),
    adr                             DECIMAL(10,2),
    required_car_parking_spaces     INT,
    total_of_special_requests       INT,
    reservation_status              VARCHAR(20),
    reservation_status_date         DATE
);

-- -----------------------------------------------------------------------------
-- HOW TO LOAD DATA
-- Update the file path to match your local CSV location, then uncomment:
-- -----------------------------------------------------------------------------
/*
LOAD DATA INFILE '/path/to/hotel_bookings.csv'
INTO TABLE hotel_bookings
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(hotel, is_canceled, lead_time, arrival_date_year, arrival_date_month,
 arrival_date_week_number, arrival_date_day_of_month, stays_in_weekend_nights,
 stays_in_week_nights, adults, children, babies, meal, country, market_segment,
 distribution_channel, is_repeated_guest, previous_cancellations,
 previous_bookings_not_canceled, reserved_room_type, assigned_room_type,
 booking_changes, deposit_type, agent, company, days_in_waiting_list,
 customer_type, adr, required_car_parking_spaces, total_of_special_requests,
 reservation_status, reservation_status_date);
*/


-- =============================================================================
-- SECTION 1 : DATA CLEANING & QUALITY CHECKS
-- =============================================================================

-- 1.1  Overview of raw data
SELECT COUNT(*)                         AS total_rows,
       COUNT(DISTINCT hotel)            AS hotel_types,
       COUNT(DISTINCT country)          AS countries,
       COUNT(DISTINCT market_segment)   AS market_segments,
       COUNT(DISTINCT distribution_channel) AS dist_channels,
       MIN(arrival_date_year)           AS earliest_year,
       MAX(arrival_date_year)           AS latest_year
FROM hotel_bookings;

-- 1.2  NULL / missing value audit
SELECT
    SUM(CASE WHEN children  IS NULL THEN 1 ELSE 0 END) AS null_children,
    SUM(CASE WHEN country   IS NULL THEN 1 ELSE 0 END) AS null_country,
    SUM(CASE WHEN agent     IS NULL THEN 1 ELSE 0 END) AS null_agent,
    SUM(CASE WHEN company   IS NULL THEN 1 ELSE 0 END) AS null_company,
    SUM(CASE WHEN adr       IS NULL THEN 1 ELSE 0 END) AS null_adr,
    SUM(CASE WHEN meal      IS NULL THEN 1 ELSE 0 END) AS null_meal
FROM hotel_bookings;

-- 1.3  Fix NULLs with safe defaults
SET SQL_SAFE_UPDATES = 0;

UPDATE hotel_bookings SET children = 0         WHERE children IS NULL;
UPDATE hotel_bookings SET country  = 'Unknown' WHERE country  IS NULL;

-- 1.4  Remove logical impossibilities
-- Zero-occupancy bookings (no guests at all)
DELETE FROM hotel_bookings
WHERE adults = 0 AND children = 0 AND babies = 0;

-- Negative ADR (data entry error)
DELETE FROM hotel_bookings
WHERE adr < 0;

-- Extreme ADR outlier (>5000 — statistical outlier, single record)
DELETE FROM hotel_bookings
WHERE adr > 5000;

-- 1.5  Standardise "Undefined" categorical values
UPDATE hotel_bookings SET meal                 = 'SC'    WHERE meal                 = 'Undefined';
UPDATE hotel_bookings SET market_segment       = 'Other' WHERE market_segment       = 'Undefined';
UPDATE hotel_bookings SET distribution_channel = 'Other' WHERE distribution_channel = 'Undefined';

SET SQL_SAFE_UPDATES = 1;

-- 1.6  Add derived / helper generated columns
ALTER TABLE hotel_bookings
    ADD COLUMN total_nights  INT     GENERATED ALWAYS AS (stays_in_weekend_nights + stays_in_week_nights) STORED,
    ADD COLUMN room_changed  TINYINT GENERATED ALWAYS AS (reserved_room_type <> assigned_room_type)       STORED,
    ADD COLUMN is_domestic   TINYINT GENERATED ALWAYS AS (country = 'PRT')                                STORED,
    ADD COLUMN total_guests  INT     GENERATED ALWAYS AS (adults + children + babies)                     STORED;

-- 1.7  Verify cleaned row count
SELECT COUNT(*) AS rows_after_cleaning FROM hotel_bookings;


-- =============================================================================
-- SECTION 2 : OVERVIEW & DEMAND SUMMARY
-- =============================================================================

-- 2.1  Booking volume by hotel type
SELECT
    hotel,
    COUNT(*)                                      AS total_bookings,
    SUM(is_canceled)                              AS cancellations,
    COUNT(*) - SUM(is_canceled)                   AS successful_stays,
    ROUND(SUM(is_canceled) * 100.0 / COUNT(*), 2) AS cancellation_rate_pct
FROM hotel_bookings
GROUP BY hotel
ORDER BY total_bookings DESC;

-- 2.2  Booking volume by year with ADR trend
SELECT
    arrival_date_year                             AS year,
    COUNT(*)                                      AS total_bookings,
    SUM(is_canceled)                              AS cancellations,
    ROUND(AVG(adr), 2)                            AS avg_daily_rate,
    ROUND(SUM(CASE WHEN is_canceled=0 THEN adr * total_nights ELSE 0 END), 2) AS est_revenue
FROM hotel_bookings
GROUP BY arrival_date_year
ORDER BY year;

-- 2.3  Confirmed stays by hotel and year (demand trend)
SELECT
    hotel,
    arrival_date_year                             AS year,
    COUNT(*)                                      AS total_bookings,
    SUM(CASE WHEN is_canceled = 0 THEN 1 ELSE 0 END) AS confirmed_stays,
    ROUND(SUM(is_canceled) * 100.0 / COUNT(*), 2) AS cancel_rate_pct
FROM hotel_bookings
GROUP BY hotel, arrival_date_year
ORDER BY hotel, year;


-- =============================================================================
-- SECTION 3 : PEAK BOOKING & SEASONALITY ANALYSIS
-- =============================================================================

-- 3.1  Monthly booking demand (all years combined)
SELECT
    arrival_date_month                                AS month,
    COUNT(*)                                          AS total_bookings,
    SUM(CASE WHEN is_canceled = 0 THEN 1 ELSE 0 END) AS actual_arrivals,
    ROUND(AVG(adr), 2)                                AS avg_daily_rate,
    ROUND(SUM(is_canceled) * 100.0 / COUNT(*), 2)    AS cancellation_rate_pct
FROM hotel_bookings
GROUP BY arrival_date_month
ORDER BY FIELD(arrival_date_month,
    'January','February','March','April','May','June',
    'July','August','September','October','November','December');

-- 3.2  Peak month per hotel type (confirmed stays only)
SELECT
    hotel,
    arrival_date_month                                AS month,
    COUNT(*)                                          AS confirmed_bookings,
    ROUND(AVG(adr), 2)                                AS avg_adr
FROM hotel_bookings
WHERE is_canceled = 0
GROUP BY hotel, arrival_date_month
ORDER BY hotel, confirmed_bookings DESC;

-- 3.3  Best time to book: lowest ADR + lowest cancellation rate
SELECT
    arrival_date_month                                AS month,
    ROUND(AVG(adr), 2)                                AS avg_adr,
    ROUND(SUM(is_canceled)*100.0/COUNT(*), 2)         AS cancel_rate_pct,
    ROUND(AVG(lead_time), 0)                          AS avg_lead_time_days
FROM hotel_bookings
GROUP BY arrival_date_month
ORDER BY avg_adr ASC, cancel_rate_pct ASC;

-- 3.4  Weekly demand heat-map (week number x hotel)
SELECT
    hotel,
    arrival_date_week_number                          AS week_number,
    COUNT(*)                                          AS bookings,
    ROUND(AVG(adr), 2)                                AS avg_adr
FROM hotel_bookings
WHERE is_canceled = 0
GROUP BY hotel, arrival_date_week_number
ORDER BY hotel, week_number;


-- =============================================================================
-- SECTION 4 : GEOGRAPHIC ANALYSIS
-- =============================================================================

-- 4.1  Top 15 source countries by booking volume
SELECT
    country,
    COUNT(*)                                          AS total_bookings,
    SUM(is_canceled)                                  AS cancellations,
    ROUND(SUM(is_canceled)*100.0/COUNT(*), 2)         AS cancel_rate_pct,
    ROUND(AVG(adr), 2)                                AS avg_adr
FROM hotel_bookings
WHERE country <> 'Unknown'
GROUP BY country
ORDER BY total_bookings DESC
LIMIT 15;

-- 4.2  Domestic (Portugal) vs. International guests
SELECT
    CASE WHEN is_domestic = 1 THEN 'Domestic (PRT)' ELSE 'International' END AS guest_origin,
    COUNT(*)                                          AS total_bookings,
    SUM(is_canceled)                                  AS cancellations,
    ROUND(SUM(is_canceled)*100.0/COUNT(*), 2)         AS cancel_rate_pct,
    ROUND(AVG(adr), 2)                                AS avg_adr,
    ROUND(AVG(lead_time), 0)                          AS avg_lead_time_days
FROM hotel_bookings
GROUP BY is_domestic;

-- 4.3  Top revenue-generating countries
SELECT
    country,
    COUNT(*)                                          AS bookings,
    ROUND(SUM(CASE WHEN is_canceled=0 THEN adr * total_nights ELSE 0 END), 2) AS estimated_revenue,
    ROUND(AVG(CASE WHEN is_canceled=0 THEN adr END), 2) AS avg_adr,
    ROUND(SUM(is_canceled)*100.0/COUNT(*), 2)         AS cancel_rate_pct
FROM hotel_bookings
WHERE country <> 'Unknown'
GROUP BY country
ORDER BY estimated_revenue DESC
LIMIT 15;

-- 4.4  Geographic cancellation hotspots (min 100 bookings)
SELECT
    country,
    COUNT(*)                                          AS total_bookings,
    SUM(is_canceled)                                  AS cancellations,
    ROUND(SUM(is_canceled)*100.0/COUNT(*), 2)         AS cancel_rate_pct
FROM hotel_bookings
WHERE country <> 'Unknown'
GROUP BY country
HAVING total_bookings >= 100
ORDER BY cancel_rate_pct DESC
LIMIT 15;


-- =============================================================================
-- SECTION 5 : CUSTOMER DEMOGRAPHICS & SEGMENTATION
-- =============================================================================

-- 5.1  Bookings by market segment
SELECT
    market_segment,
    COUNT(*)                                          AS total_bookings,
    SUM(is_canceled)                                  AS cancellations,
    ROUND(SUM(is_canceled)*100.0/COUNT(*), 2)         AS cancel_rate_pct,
    ROUND(AVG(adr), 2)                                AS avg_adr,
    ROUND(AVG(lead_time), 0)                          AS avg_lead_time_days,
    ROUND(AVG(total_nights), 1)                       AS avg_stay_nights
FROM hotel_bookings
GROUP BY market_segment
ORDER BY total_bookings DESC;

-- 5.2  Customer type breakdown
SELECT
    customer_type,
    COUNT(*)                                          AS total_bookings,
    ROUND(SUM(is_canceled)*100.0/COUNT(*), 2)         AS cancel_rate_pct,
    ROUND(AVG(adr), 2)                                AS avg_adr,
    ROUND(AVG(lead_time), 0)                          AS avg_lead_time_days,
    ROUND(AVG(total_guests), 1)                       AS avg_party_size
FROM hotel_bookings
GROUP BY customer_type
ORDER BY total_bookings DESC;

-- 5.3  Lead time segmentation (booking horizon buckets)
SELECT
    CASE
        WHEN lead_time BETWEEN 0   AND 7   THEN '0-7 days (Last minute)'
        WHEN lead_time BETWEEN 8   AND 30  THEN '8-30 days (Short lead)'
        WHEN lead_time BETWEEN 31  AND 90  THEN '31-90 days (Medium lead)'
        WHEN lead_time BETWEEN 91  AND 180 THEN '91-180 days (Long lead)'
        ELSE '180+ days (Very long lead)'
    END                                               AS lead_time_bucket,
    COUNT(*)                                          AS bookings,
    ROUND(SUM(is_canceled)*100.0/COUNT(*), 2)         AS cancel_rate_pct,
    ROUND(AVG(adr), 2)                                AS avg_adr
FROM hotel_bookings
GROUP BY lead_time_bucket
ORDER BY MIN(lead_time);

-- 5.4  Party size distribution
SELECT
    total_guests                                      AS party_size,
    COUNT(*)                                          AS bookings,
    ROUND(SUM(is_canceled)*100.0/COUNT(*), 2)         AS cancel_rate_pct,
    ROUND(AVG(adr), 2)                                AS avg_adr
FROM hotel_bookings
WHERE total_guests BETWEEN 1 AND 10
GROUP BY total_guests
ORDER BY party_size;

-- 5.5  Repeat vs. new guests
SELECT
    CASE WHEN is_repeated_guest = 1 THEN 'Repeat Guest' ELSE 'New Guest' END AS guest_status,
    COUNT(*)                                          AS total_bookings,
    ROUND(SUM(is_canceled)*100.0/COUNT(*), 2)         AS cancel_rate_pct,
    ROUND(AVG(adr), 2)                                AS avg_adr,
    ROUND(AVG(total_of_special_requests), 2)          AS avg_special_requests,
    ROUND(AVG(total_nights), 1)                       AS avg_stay_nights
FROM hotel_bookings
GROUP BY is_repeated_guest;


-- =============================================================================
-- SECTION 6 : REVENUE & PRICING ANALYSIS (ADR)
-- =============================================================================

-- 6.1  Average Daily Rate statistics by hotel type
SELECT
    hotel,
    ROUND(AVG(adr), 2)                                AS avg_adr,
    ROUND(MIN(adr), 2)                                AS min_adr,
    ROUND(MAX(adr), 2)                                AS max_adr,
    ROUND(STDDEV(adr), 2)                             AS adr_std_dev,
    COUNT(*)                                          AS bookings
FROM hotel_bookings
WHERE is_canceled = 0 AND adr > 0
GROUP BY hotel;

-- 6.2  ADR by room type (reserved) per hotel
SELECT
    reserved_room_type                                AS room_type,
    hotel,
    COUNT(*)                                          AS bookings,
    ROUND(AVG(adr), 2)                                AS avg_adr,
    ROUND(AVG(total_nights), 1)                       AS avg_stay_nights,
    ROUND(AVG(adr) * AVG(total_nights), 2)            AS est_avg_revenue_per_stay
FROM hotel_bookings
WHERE is_canceled = 0 AND adr > 0
GROUP BY reserved_room_type, hotel
ORDER BY avg_adr DESC;

-- 6.3  ADR by market segment
SELECT
    market_segment,
    ROUND(AVG(adr), 2)                                AS avg_adr,
    COUNT(*)                                          AS bookings,
    ROUND(SUM(is_canceled)*100.0/COUNT(*), 2)         AS cancel_rate_pct
FROM hotel_bookings
GROUP BY market_segment
ORDER BY avg_adr DESC;

-- 6.4  Monthly ADR pivot: City Hotel vs Resort Hotel (side-by-side)
SELECT
    arrival_date_month                                AS month,
    ROUND(AVG(CASE WHEN hotel='City Hotel'   AND is_canceled=0 THEN adr END), 2) AS city_hotel_adr,
    ROUND(AVG(CASE WHEN hotel='Resort Hotel' AND is_canceled=0 THEN adr END), 2) AS resort_hotel_adr,
    COUNT(CASE WHEN hotel='City Hotel'   AND is_canceled=0 THEN 1 END)           AS city_stays,
    COUNT(CASE WHEN hotel='Resort Hotel' AND is_canceled=0 THEN 1 END)           AS resort_stays
FROM hotel_bookings
GROUP BY arrival_date_month
ORDER BY FIELD(arrival_date_month,
    'January','February','March','April','May','June',
    'July','August','September','October','November','December');

-- 6.5  Optimal stay length for ADR
SELECT
    CASE
        WHEN total_nights = 1               THEN '1 night'
        WHEN total_nights = 2               THEN '2 nights'
        WHEN total_nights = 3               THEN '3 nights'
        WHEN total_nights BETWEEN 4  AND 7  THEN '4-7 nights'
        WHEN total_nights BETWEEN 8  AND 14 THEN '8-14 nights'
        ELSE '15+ nights'
    END                                               AS stay_length,
    hotel,
    COUNT(*)                                          AS bookings,
    ROUND(AVG(adr), 2)                                AS avg_adr
FROM hotel_bookings
WHERE is_canceled = 0 AND adr > 0 AND total_nights > 0
GROUP BY stay_length, hotel
ORDER BY avg_adr DESC;


-- =============================================================================
-- SECTION 7 : CANCELLATION ANALYSIS
-- =============================================================================

-- 7.1  Overall cancellation rate
SELECT
    COUNT(*)                                          AS total_bookings,
    SUM(is_canceled)                                  AS total_cancellations,
    ROUND(SUM(is_canceled)*100.0/COUNT(*), 2)         AS overall_cancel_rate_pct
FROM hotel_bookings;

-- 7.2  Cancellation rate by deposit type
SELECT
    deposit_type,
    COUNT(*)                                          AS bookings,
    SUM(is_canceled)                                  AS cancellations,
    ROUND(SUM(is_canceled)*100.0/COUNT(*), 2)         AS cancel_rate_pct,
    ROUND(AVG(lead_time), 0)                          AS avg_lead_time_days
FROM hotel_bookings
GROUP BY deposit_type
ORDER BY cancel_rate_pct DESC;

-- 7.3  Cancellation rate by distribution channel
SELECT
    distribution_channel,
    COUNT(*)                                          AS bookings,
    SUM(is_canceled)                                  AS cancellations,
    ROUND(SUM(is_canceled)*100.0/COUNT(*), 2)         AS cancel_rate_pct,
    ROUND(AVG(days_in_waiting_list), 1)               AS avg_waitlist_days,
    ROUND(AVG(adr), 2)                                AS avg_adr
FROM hotel_bookings
GROUP BY distribution_channel
ORDER BY cancel_rate_pct ASC;

-- 7.4  Cancellation rate by lead time bucket
SELECT
    CASE
        WHEN lead_time BETWEEN 0   AND 7   THEN '0-7 days'
        WHEN lead_time BETWEEN 8   AND 30  THEN '8-30 days'
        WHEN lead_time BETWEEN 31  AND 90  THEN '31-90 days'
        WHEN lead_time BETWEEN 91  AND 180 THEN '91-180 days'
        ELSE '180+ days'
    END                                               AS lead_time_bucket,
    COUNT(*)                                          AS bookings,
    ROUND(SUM(is_canceled)*100.0/COUNT(*), 2)         AS cancel_rate_pct
FROM hotel_bookings
GROUP BY lead_time_bucket
ORDER BY MIN(lead_time);

-- 7.5  Cancellation by prior cancellation history
SELECT
    CASE
        WHEN previous_cancellations = 0 THEN 'No prior cancellations'
        WHEN previous_cancellations = 1 THEN '1 prior cancellation'
        ELSE '2+ prior cancellations'
    END                                               AS cancellation_history,
    COUNT(*)                                          AS bookings,
    ROUND(SUM(is_canceled)*100.0/COUNT(*), 2)         AS cancel_rate_pct
FROM hotel_bookings
GROUP BY cancellation_history
ORDER BY cancel_rate_pct DESC;

-- 7.6  High-risk cancellation profile (combined risk factors)
SELECT
    deposit_type,
    distribution_channel,
    CASE
        WHEN lead_time > 180 THEN 'Long (>180 days)'
        WHEN lead_time > 90  THEN 'Medium (91-180 days)'
        ELSE 'Short (<=90 days)'
    END                                               AS lead_time_group,
    COUNT(*)                                          AS bookings,
    ROUND(SUM(is_canceled)*100.0/COUNT(*), 2)         AS cancel_rate_pct
FROM hotel_bookings
GROUP BY deposit_type, distribution_channel, lead_time_group
HAVING bookings >= 50
ORDER BY cancel_rate_pct DESC
LIMIT 20;

-- 7.7  Effect of booking changes on cancellation rate
SELECT
    CASE
        WHEN booking_changes = 0             THEN 'No changes'
        WHEN booking_changes = 1             THEN '1 change'
        WHEN booking_changes BETWEEN 2 AND 3 THEN '2-3 changes'
        ELSE '4+ changes'
    END                                               AS change_category,
    COUNT(*)                                          AS bookings,
    ROUND(SUM(is_canceled)*100.0/COUNT(*), 2)         AS cancel_rate_pct,
    ROUND(AVG(adr), 2)                                AS avg_adr
FROM hotel_bookings
GROUP BY change_category
ORDER BY MIN(booking_changes);


-- =============================================================================
-- SECTION 8 : ROOM TYPE & REASSIGNMENT ANALYSIS
-- =============================================================================

-- 8.1  Room reassignment rate by hotel type
SELECT
    hotel,
    COUNT(*)                                          AS total_stays,
    SUM(room_changed)                                 AS reassignments,
    ROUND(SUM(room_changed)*100.0/COUNT(*), 2)        AS reassignment_rate_pct
FROM hotel_bookings
WHERE is_canceled = 0
GROUP BY hotel;

-- 8.2  Impact of room reassignment on key metrics
SELECT
    CASE WHEN room_changed = 1 THEN 'Reassigned' ELSE 'Got Reserved Room' END AS room_outcome,
    COUNT(*)                                          AS bookings,
    ROUND(AVG(adr), 2)                                AS avg_adr,
    ROUND(AVG(total_of_special_requests), 2)          AS avg_special_requests,
    ROUND(AVG(total_nights), 1)                       AS avg_nights,
    ROUND(SUM(is_canceled)*100.0/COUNT(*), 2)         AS cancel_rate_pct
FROM hotel_bookings
GROUP BY room_changed;

-- 8.3  Room type flow: reserved vs assigned (top combinations)
SELECT
    reserved_room_type,
    assigned_room_type,
    COUNT(*)                                          AS count,
    CASE WHEN reserved_room_type = assigned_room_type THEN 'Same' ELSE 'Changed' END AS outcome
FROM hotel_bookings
WHERE is_canceled = 0
GROUP BY reserved_room_type, assigned_room_type
ORDER BY count DESC;

-- 8.4  Revenue performance by assigned room type
SELECT
    assigned_room_type                                AS room_type,
    COUNT(*)                                          AS stays,
    ROUND(AVG(adr), 2)                                AS avg_adr,
    ROUND(AVG(total_nights), 1)                       AS avg_stay_nights,
    ROUND(SUM(adr * total_nights), 2)                 AS total_revenue_estimate
FROM hotel_bookings
WHERE is_canceled = 0 AND adr > 0 AND total_nights > 0
GROUP BY assigned_room_type
ORDER BY total_revenue_estimate DESC;


-- =============================================================================
-- SECTION 9 : OPERATIONAL EFFICIENCY
-- =============================================================================

-- 9.1  Special requests vs cancellation and ADR
SELECT
    total_of_special_requests                         AS special_requests,
    COUNT(*)                                          AS bookings,
    ROUND(AVG(adr), 2)                                AS avg_adr,
    ROUND(SUM(is_canceled)*100.0/COUNT(*), 2)         AS cancel_rate_pct,
    ROUND(AVG(lead_time), 0)                          AS avg_lead_time_days
FROM hotel_bookings
GROUP BY total_of_special_requests
ORDER BY special_requests;

-- 9.2  Parking demand by hotel type
SELECT
    hotel,
    SUM(required_car_parking_spaces)                  AS total_parking_requested,
    ROUND(AVG(required_car_parking_spaces), 3)        AS avg_parking_per_booking,
    SUM(CASE WHEN required_car_parking_spaces > 0 THEN 1 ELSE 0 END) AS bookings_needing_parking,
    ROUND(SUM(CASE WHEN required_car_parking_spaces > 0 THEN 1 ELSE 0 END)*100.0/COUNT(*), 2)
                                                      AS parking_demand_pct
FROM hotel_bookings
WHERE is_canceled = 0
GROUP BY hotel;

-- 9.3  Meal plan preference by market segment (with window function)
SELECT
    market_segment,
    meal,
    COUNT(*)                                          AS bookings,
    ROUND(COUNT(*)*100.0 / SUM(COUNT(*)) OVER (PARTITION BY market_segment), 2) AS pct_within_segment
FROM hotel_bookings
WHERE is_canceled = 0
GROUP BY market_segment, meal
ORDER BY market_segment, bookings DESC;

-- 9.4  Waiting list analysis by distribution channel
SELECT
    distribution_channel,
    COUNT(*)                                          AS bookings,
    SUM(CASE WHEN days_in_waiting_list > 0 THEN 1 ELSE 0 END) AS bookings_with_waitlist,
    ROUND(AVG(CASE WHEN days_in_waiting_list > 0 THEN days_in_waiting_list END), 1)
                                                      AS avg_wait_days_when_listed,
    MAX(days_in_waiting_list)                         AS max_wait_days
FROM hotel_bookings
GROUP BY distribution_channel
ORDER BY avg_wait_days_when_listed DESC;

-- 9.5  High special-request predictor profile
SELECT
    market_segment,
    customer_type,
    ROUND(AVG(total_of_special_requests), 3)          AS avg_special_requests,
    COUNT(*)                                          AS bookings,
    ROUND(SUM(CASE WHEN total_of_special_requests >= 3 THEN 1 ELSE 0 END)*100.0/COUNT(*), 2)
                                                      AS pct_high_requests
FROM hotel_bookings
WHERE is_canceled = 0
GROUP BY market_segment, customer_type
HAVING bookings >= 30
ORDER BY avg_special_requests DESC
LIMIT 20;


-- =============================================================================
-- SECTION 10 : ADVANCED / COMBINED INSIGHT QUERIES
-- =============================================================================

-- 10.1  Revenue KPI dashboard (hotel x year)
SELECT
    hotel,
    arrival_date_year                                 AS year,
    COUNT(*)                                          AS total_bookings,
    SUM(CASE WHEN is_canceled = 0 THEN 1 ELSE 0 END) AS confirmed_stays,
    ROUND(SUM(is_canceled)*100.0/COUNT(*), 2)         AS cancel_rate_pct,
    ROUND(AVG(CASE WHEN is_canceled=0 THEN adr END), 2) AS avg_adr_confirmed,
    ROUND(SUM(CASE WHEN is_canceled=0 THEN adr * total_nights ELSE 0 END), 2) AS estimated_total_revenue,
    ROUND(AVG(CASE WHEN is_canceled=0 THEN total_nights END), 1) AS avg_stay_nights,
    ROUND(AVG(lead_time), 0)                          AS avg_lead_time_days
FROM hotel_bookings
GROUP BY hotel, arrival_date_year
ORDER BY hotel, year;

-- 10.2  Channel effectiveness scorecard
--       (composite score: high ADR good, high cancel bad, long wait bad)
SELECT
    distribution_channel,
    COUNT(*)                                          AS bookings,
    ROUND(AVG(adr), 2)                                AS avg_adr,
    ROUND(SUM(is_canceled)*100.0/COUNT(*), 2)         AS cancel_rate_pct,
    ROUND(AVG(days_in_waiting_list), 2)               AS avg_waitlist_days,
    ROUND(AVG(lead_time), 0)                          AS avg_lead_time_days,
    ROUND(
        (SUM(is_canceled)*100.0/COUNT(*))
        - (AVG(adr)/10)
        + AVG(days_in_waiting_list),
    2)                                                AS risk_score
FROM hotel_bookings
GROUP BY distribution_channel
ORDER BY risk_score ASC;

-- 10.3  Domestic vs International trend by year (confirmed stays)
SELECT
    arrival_date_year                                 AS year,
    CASE WHEN is_domestic = 1 THEN 'Domestic' ELSE 'International' END AS guest_origin,
    COUNT(*)                                          AS bookings,
    ROUND(AVG(adr), 2)                                AS avg_adr
FROM hotel_bookings
WHERE is_canceled = 0
GROUP BY year, is_domestic
ORDER BY year, is_domestic;

-- 10.4  Market segment x meal plan preference
SELECT
    market_segment,
    meal,
    COUNT(*)                                          AS bookings,
    ROUND(COUNT(*)*100.0/SUM(COUNT(*)) OVER (PARTITION BY market_segment), 2) AS pct_within_segment
FROM hotel_bookings
WHERE is_canceled = 0
GROUP BY market_segment, meal
ORDER BY market_segment, bookings DESC;


-- =============================================================================
-- SECTION 11 : KEY INSIGHT SUMMARIES (BUSINESS ANSWERS)
-- =============================================================================

-- INSIGHT 1: Best month to book (lowest ADR + fewest cancellations)
SELECT
    'Best Month to Book'                              AS insight,
    arrival_date_month                                AS value,
    ROUND(AVG(adr), 2)                                AS avg_adr,
    ROUND(SUM(is_canceled)*100.0/COUNT(*), 2)         AS cancel_rate_pct
FROM hotel_bookings
GROUP BY arrival_date_month
ORDER BY avg_adr ASC
LIMIT 1;

-- INSIGHT 2: Distribution channel with lowest cancellation rate
SELECT
    'Best Distribution Channel (Lowest Cancellation)' AS insight,
    distribution_channel                              AS value,
    ROUND(SUM(is_canceled)*100.0/COUNT(*), 2)         AS cancel_rate_pct,
    ROUND(AVG(days_in_waiting_list), 1)               AS avg_waitlist_days
FROM hotel_bookings
WHERE distribution_channel <> 'Other'
GROUP BY distribution_channel
ORDER BY cancel_rate_pct ASC
LIMIT 1;

-- INSIGHT 3: Room type with highest average revenue per stay
SELECT
    'Highest Revenue Room Type'                       AS insight,
    assigned_room_type                                AS value,
    ROUND(AVG(adr), 2)                                AS avg_adr,
    ROUND(AVG(adr * total_nights), 2)                 AS avg_revenue_per_stay
FROM hotel_bookings
WHERE is_canceled = 0 AND adr > 0 AND total_nights > 0
GROUP BY assigned_room_type
ORDER BY avg_revenue_per_stay DESC
LIMIT 1;

-- INSIGHT 4: Do room reassignments lead to more cancellations?
SELECT
    'Room Reassignment Effect'                        AS insight,
    CASE WHEN room_changed = 1 THEN 'Reassigned' ELSE 'Not Reassigned' END AS group_label,
    COUNT(*)                                          AS bookings,
    ROUND(SUM(is_canceled)*100.0/COUNT(*), 2)         AS cancel_rate_pct
FROM hotel_bookings
GROUP BY room_changed;

-- INSIGHT 5: Peak booking month overall (confirmed stays)
SELECT
    'Peak Booking Month'                              AS insight,
    arrival_date_month                                AS value,
    COUNT(*)                                          AS total_bookings
FROM hotel_bookings
WHERE is_canceled = 0
GROUP BY arrival_date_month
ORDER BY total_bookings DESC
LIMIT 1;

-- INSIGHT 6: Repeat vs new guest cancellation comparison
SELECT
    'Repeat vs New Guest Cancel Rate'                 AS insight,
    CASE WHEN is_repeated_guest=1 THEN 'Repeat Guest' ELSE 'New Guest' END AS group_label,
    COUNT(*)                                          AS bookings,
    ROUND(SUM(is_canceled)*100.0/COUNT(*), 2)         AS cancel_rate_pct,
    ROUND(AVG(adr), 2)                                AS avg_adr
FROM hotel_bookings
GROUP BY is_repeated_guest;

-- INSIGHT 7: Optimal deposit strategy (cancel rate vs revenue trade-off)
SELECT
    deposit_type,
    COUNT(*)                                          AS bookings,
    ROUND(SUM(is_canceled)*100.0/COUNT(*), 2)         AS cancel_rate_pct,
    ROUND(AVG(CASE WHEN is_canceled=0 THEN adr END), 2) AS avg_adr_on_stays,
    ROUND(SUM(CASE WHEN is_canceled=0 THEN adr * total_nights ELSE 0 END), 2) AS total_est_revenue
FROM hotel_bookings
GROUP BY deposit_type
ORDER BY total_est_revenue DESC;

-- =============================================================================
-- END OF ANALYSIS
-- Hotel Bookings EDA — MySQL Project
-- Sections covered: Setup, Cleaning, Demand, Seasonality, Geography,
--   Segmentation, Revenue, Cancellations, Rooms, Operations, Advanced, Insights
-- =============================================================================
